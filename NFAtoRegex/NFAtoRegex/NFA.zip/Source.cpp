#include <iostream>
#include <fstream>
#include "Regex.h"

void printMenu()
{
	std::cout << "0 - print automaton" << std::endl;
	std::cout << "1 - get regular expression" << std::endl;
	std::cout << "2 - check if a word is accepted by the regular expression" << std::endl;
	std::cout << "3 - exit" << std::endl;
}

void printOptions(const NFA& nfa)
{
	int option = 0;
	const int OPTIONS = 3;
	Regex reg(nfa);
	std::string word{};
	while (option != OPTIONS)
	{
		printMenu();
		std::cin >> option;
		switch (option)
		{
		case 0:
			nfa.printAutomaton();
			system("pause");
			system("cls");
			break;
		case 1:
			std::cout << reg.getPattern() << std::endl;
			system("pause");
			system("cls");
			break;
		case 2:
			std::cout << "Please introduce the word you wish to check: ";
			std::cin >> word;
			if (nfa.checkWord(word))
			{
				std::cout << "The word is accepted by the regular expression" << std::endl;;
			}
			else
			{
				std::cout << "The word is NOT accepted by the regular expression" << std::endl;;
			}
			system("pause");
			system("cls");
			break;
		case 3:
			break;
		default:
			std::cout << "Please introduce a valid option";
			system("pause");
			system("cls");
			break;
		}
	}
}

int main()
{
	try {
		NFA nfa("Input.txt");
		printOptions(nfa);
	}
	catch (const std::exception& ex) {
		std::cerr << "Exception caught: " << ex.what() << std::endl;
	}
	return 0;
}