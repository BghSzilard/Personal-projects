#pragma once
#include "NFA.h"

class StateCompare
{
private:
	NFA m_nfa;
public:
    StateCompare(NFA nfa) : m_nfa(nfa) {}

    bool operator()(char state1, char state2) const {
        return m_nfa.getIncomingStates(state1).size() + m_nfa.getOutgoingStates(state1).size() >
            m_nfa.getIncomingStates(state2).size() + m_nfa.getOutgoingStates(state2).size();
    }
};

